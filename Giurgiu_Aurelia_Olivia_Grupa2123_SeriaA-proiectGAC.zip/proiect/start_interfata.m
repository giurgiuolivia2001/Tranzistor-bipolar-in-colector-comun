clear all;
close all;
clc;

R1=130000;
R2=11000;
Rc=10000;
Re=1000;
R0=500;
b=100;%beta

Vcc=22;
VBE=0.7;
Ic=0.00091;%Amperi
cb=1;
rb1=0;
rb2=0;
A=5;
f=100;
N=4;%nr perioade

tranzistor_cc(R1,R2,Rc,Re,R0,b,Vcc,VBE,Ic,cb,rb1,rb2,A,f,N);
